#!/usr/bin/python2.7
import os
import sys
sys.path.append("/root/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream/ace/python-modules")
curdir = os.path.abspath(os.path.dirname(sys.argv[0]))
from ACEStream.Plugin.EngineConsole import start
apptype = 'acestream'
start(apptype, curdir)

