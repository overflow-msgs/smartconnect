#Embedded file name: ACEStream\Core\Overlay\__init__.pyo
pass
