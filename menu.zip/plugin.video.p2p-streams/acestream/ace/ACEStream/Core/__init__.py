#Embedded file name: ACEStream\Core\__init__.pyo
pass
