#Embedded file name: ACEStream\Category\__init__.pyo
pass
