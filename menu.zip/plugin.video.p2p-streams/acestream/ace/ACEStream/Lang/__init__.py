#Embedded file name: ACEStream\Lang\__init__.pyo
pass
