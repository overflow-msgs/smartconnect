### ############################################################################################################
###	#	
### # Site: 				#		
### # Author: 			#		The Highway
### # Description: 	#		
###	#	
### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc
import os,sys,string,StringIO,logging,random,array,time,datetime,re
try: import copy
except: pass
import urllib,urllib2,xbmcaddon,xbmcplugin,xbmcgui
from common import *
from common import (_addon,_artIcon,_artFanart,_addonPath,_debugging,_OpenFile,_SaveFile)
import common as Common
### ############################################################################################################
### ############################################################################################################
SiteName='seriale-ro'
SiteTag='seriale-ro'
mainSite='http://clicksud.com'
mainSite2='http://www.clicksud.com'
iconSite=_artIcon #
fanartSite=_artFanart #
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'orange','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet','10':'hotpink','11':'pink','12':'tan','13':'firebrick','14':'mediumpurple'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
#MyGenres=['Seriale','Animatie','Aventura','Biografic','Comedie','Dragoste','Drama','Familie','Fantezie','Filme-Vechi','Horror','Istoric','Mister','Muzica','Psihologic','Razboi','Romantic','Science-Fiction','Sport','Thriller','Western','Filme-Documentare-Online','Film-Noir','Filme-Indiene']
MyGenres=[['Seriale','Seriale','Series'],['Filme-Vechi','Filme Vechi','Old Movies'],['Animatie','Animatie','Animation'],['Aventura','Aventura','Adventure'],['Biografic','Biografic','Biographical'],['Comedie','Comedie','Comedy'],['Dragoste','Dragoste','Love'],['Drama','Drama','Drama'],['Familie','Familie','Family'],['Fantezie','Fantezie','Fantasy'],['Horror','Horror','Horror'],['Istoric','Istoric','Historical'],['Mister','Mister','Mystery'],['Muzica','Muzica','Music'],['Psihologic','Psihologic','Psychological'],['Razboi','Razboi','War'],['Romantic','Romantic','Romance'],['Science-Fiction','Science Fiction','Sci-Fi'],['Sport','Sport','Sports'],['Thriller','Thriller','Thriller'],['Western','Western','Western'],['Filme-Documentare-Online','Filme Documentare Online','Documentary Film Online'],['Film-Noir','Film Noir','Film Noir'],['despre/filme-indiene','Filme Indiene','Indian Movies'],['despre/filme-nominalizate-la-oscar','Filme Nominalizate la Oscar','Nominated for Oscar'],['despre/filme-oscar','Filme Oscar','Oscar Movies'],['despre/nominalizari-globul-de-aur','Nominalizari Globul de Aur','Golden Globe Nominations']]
MyYears=['2014','2013','2012','2011','2010','2009','2008','2007','2006','2005','2004','2003','2002','2001','2000','1999','1998','1997','1996','1995','1994','1993','1992','1991','1990','1980','1970']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
ww6='[COLOR black]@[/COLOR]'; 
ww7='[COLOR FF0098BD]@[/COLOR]'; 
colorA='FFbfa67d'; colorB='FF00D0FF'; #colorA='FFbfa67d'; colorB='FFa10909'; #colorA='FF669D97'; colorB='FF3D80B1'; #colorA='FF0098BD'; colorB='FF6E81BB'; #185187
workingUrl=mainSite+''
### ############################################################################################################
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		m+='IRC Chat:  '+cFL('#TVADDONS','blueviolet')+' @ '+cFL('irc.Freenode.net','blueviolet')
		#m+=CR+'Site Name:  '+SiteName
		#m+=CR+'Site Tag:  '+SiteTag
		#m+=CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+'Varsta: Va rugam sa asigurati-va ca sunt de o varsta valabil pentru a viziona materialul prezentat.'
		#m+=CR+CR+'Known Hosts for Videos:  '
		#m+=CR+'* [embed.nowvideo.sx], [api.video.mail.ru], [vk.com]'
		#m+=CR+CR+'Features:  '
		#m+=CR+'* Browse Movies, Shows, Host Links'
		#m+=CR+'* Play Videos with UrlResolver where available'
		#m+=CR+'* Play Videos without UrlResolver where supported'
		#m+=CR+'* MetaData for Shows and Movies where available'
		#m+=CR+'* Favorites, AutoView'
		#m+=CR+'* Core Player Selector'
		#m+=CR+'* Download Videos with UrlResolver'
		#m+=CR+'* '
		m+=CR+CR+'Notes:  '
		m+=CR+'* Thanks to: TheHighway (of TVADDONS.ag) and dotSmart Media Player (dotSmart.tv / dotSmart.ro).'
		m+=CR+'* Datorita: TheHighway (de TVADDONS.ag) si dotSmart Media Player (dotSmart.tv / dotSmart.ro).'
		#m+=CR+'* '+ps('ReferalMsg')
		m+=CR+''
		m+=CR+''
		m+=CR+''
	try: DoA('Back'); 
	except: pass
	try: String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	except: pass
	#RefreshList()
def spAfterSplit(t,ss):
	if ss in t: t=t.split(ss)[1]
	return t
def spBeforeSplit(t,ss):
	if ss in t: t=t.split(ss)[0]
	return t
def FixImage(img):
	if len(img)==0: return img
	if (not 'http://' in img.lower()) and (not 'https://' in img.lower()): img=mainSite+img; 
	return img
def AFColoring(t): 
	if len(t)==0: return t
	elif len(t)==1: return cFL(t,colorA) #colorA)
	else: return cFL(cFL_(t,colorA),colorB) #colorA),colorB)
def RoAFColoring(t,t2): 
	if addst('mylanguage1','Romanian').lower()=='romanian': return AFColoring(t)
	else: return AFColoring(t2)
def RoAF(t,t2): 
	if addst('mylanguage1','Romanian').lower()=='romanian': return t
	else: return t2
def RoAFc(t,t2,c=colorA): 
	if addst('mylanguage1','Romanian').lower()=='romanian': return cFL(t,c)
	else: return cFL(t2,c)
def wwA(t,ww): #for Watched State Display
	#if   ww==7: t=ww7+t
	#elif ww==6: t=ww6+t
	return t

### ############################################################################################################
### ############################################################################################################

def psgnR(x,t=".png"): ## Romanian
	s="http://i.imgur.com/"; 
	try:
		return {
			'search': 										ROartj('button_search')
			,'all': 											ROartj('button_all')
			,'about': 										ROartj('button_about')
			,'genre': 										ROartj('button_cat')
			,'year': 											ROartj('button_years')
			#,'latest': 										ROartp('button_latest')
			,'favorites': 								ROartj('button_favs')
			,'favorites 1': 							ROartj('button_favs')
			,'favorites 2': 							ROartj('button_favs')
			,'favorites 3': 							ROartj('button_favs')
			,'favorites 4': 							ROartj('button_favs')
			,'favorites 5': 							ROartj('button_favs')
			,'favorites 6': 							ROartj('button_favs')
			,'favorites 7': 							ROartj('button_favs')
			,'img_next':									artj('button_next')
			,'img_last':									artj('button_last')
			,'img_prev':									artj('button_prev')
			,'this_year':									ROartj('button_thisyear')
			,'this_month':								ROartj('button_thismonth')
			,'latest_series':							ROartj('button_latestseries')
			,'latest_movies':							ROartj('button_latestmovies')
		}[x]
	except: debob('failed to find graphc for %s'%(x)); return ''

def psgn(x,t=".png"): ## English
	s="http://i.imgur.com/"; 
	if addst('mylanguage1','Romanian').lower()=='romanian': return psgnR(x,t)
	try:
		return {
			'search': 										artj('button_search')
			,'all': 											artj('button_all')
			,'about': 										artj('button_about')
			,'genre': 										artj('button_cat')
			,'year': 											artj('button_years')
			#,'latest': 										artj('button_latest')
			,'favorites': 								artj('button_favs')
			,'favorites 1': 							artj('button_favs')
			,'favorites 2': 							artj('button_favs')
			,'favorites 3': 							artj('button_favs')
			,'favorites 4': 							artj('button_favs')
			,'favorites 5': 							artj('button_favs')
			,'favorites 6': 							artj('button_favs')
			,'favorites 7': 							artj('button_favs')
			,'img_next':									artj('button_next')
			,'img_last':									artj('button_last')
			,'img_prev':									artj('button_prev')
			,'this_year':									artj('button_thisyear')
			,'this_month':								artj('button_thismonth')
			,'latest_series':							artj('button_latestseries')
			,'latest_movies':							artj('button_latestmovies')
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
#			,'': 								s+""+t
		}[x]
	except: debob('failed to find graphc for %s'%(x)); return ''
### ############################################################################################################
### ############################################################################################################
def PlayFromCHost(Url):
	if len(Url)==0: return
	if (mainSite not in Url) and (mainSite2 not in Url): Url=mainSite+Url; 
	deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	#s='<center>\s*(Partea .*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; 
	#try: results=re.compile(s).findall(html);
	
	
	return
	##

def CheckMedia(iFrameMatches,html,Url,title,imdb_id,img,fimg,stitle,etitle,enumber,snumber,enumber2,wwT=''):
	if len(snumber)==0: snumber='0'; 
	cooky=art('cookies.page.txt')
	#_SaveFile(cookyRu,'')
	#cooky=art('cookies.page.txt'); htmlMAILruE=messupText(nolines(nURL(url1)),True,True); deb('length of htmlMAILruE',str(len(htmlMAILruE))); #debob(htmlMAILru); 
	CookiesFromPage=_OpenFile(cooky)
							
	#if len(iFrameMatches)==0: return
	#if (mainSite not in Url) and (mainSite2 not in Url): Url=mainSite+Url; 
	###
	#_addon.addon.setSetting(id="LastShowListedURL", value=Url)
	#_addon.addon.setSetting(id="LastShowListedNAME", value=title)
	#_addon.addon.setSetting(id="LastShowListedIMG", value=img)
	#_addon.addon.setSetting(id="LastShowListedFANART", value=fimg)
	#_addon.addon.setSetting(id="LastShowListedIMDBID", value=imdb_id)
	#_addon.addon.setSetting(id="LastShowListedwwT", value=wwT)
	###
	#deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	#if len(html)==0: return
	#s="<script language='JavaScript' type='text/javascript' src='(/js_content.php.h=[0-9a-zA-Z]+)'></script>"; 
	#try: content_url=re.compile(s).findall(html)[0]; 
	#except: content_url=''; 
	#if (mainSite not in content_url) and (mainSite2 not in content_url): content_url=mainSite+content_url; 
	#deb('url for list of links',content_url); html=messupText(nolines(nURL(content_url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	#html=html.replace('</iframe>','</_iframe></iframe_>').replace("='","= '</iframe_>")#.replace('</center><center>','</__center__><center>')
	#s='</iframe_>.*?</_iframe>'; 
	#try: html2p1=re.compile(s).findall(html);
	#except: html2p1=''
	## ### ## 
	if (len(html) > 0):
			deb('len(html)',str(len(html))); 
			s0=[]; iFrameMatches=[]; 
			htmlForIframes=html.replace('\n','').replace('\r','').replace('\a','').replace('\t','')
			htmlForIframes=htmlForIframes.replace("</iframe>","</iframe\n>")
			htmlForIframes=htmlForIframes.replace("><iframe>",">\n<iframe>")
			htmlForIframes=htmlForIframes.replace("<iframe>","<<\niframe>").replace("<<\niframe>","\n<iframe>")
			##deb('htmlForIframes',xbmc.translatePath(os.path.join(_addonPath,'test.html')) );
			##Common._SaveFile(xbmc.translatePath(os.path.join(_addonPath,'test.html')),htmlForIframes)
			#s0.append("<iframe .*?src=(?:\"|')((?:\D+\:)?//(.+?)/.+?)(?:\"|')\s*.*?>\n*</iframe")
			s0.append("<iframe.*?src='(\D+://(.+?)/.+?)'.*?></iframe")
			s0.append('<iframe.*?src="(\D+://(.+?)/.+?)".*?></iframe')
			s0.append("<iframe.*?src='(//(.+?)/.+?)'.*?></iframe")
			s0.append('<iframe.*?src="(//(.+?)/.+?)".*?></iframe')
			for s in s0:
				#try: iFrameMatchesB=re.compile(s).findall(htmlForIframes); debob(['iFrameMatchesB',iFrameMatchesB])
				try: iFrameMatchesB=re.compile(s,re.IGNORECASE).findall(htmlForIframes); debob(['iFrameMatchesB',s,iFrameMatchesB])
				except: iFrameMatchesB=[]; 
				if len(iFrameMatchesB) > 0:
					for iFrameB in iFrameMatchesB:
						if not iFrameB in iFrameMatches:
							iFrameMatches.append(iFrameB)
			if len(iFrameMatches) > 0:
				debob(['iFrameMatches',iFrameMatches])
	## ### ## 
	results=iFrameMatches
	iC1=len(results); 
	if iC1 > 0:
		aSortMeth(xbmcplugin.SORT_METHOD_TITLE); 
		phtml2p=""; CentA=''; #html2p1=sorted(html2p1); 
		#for html2p in html2p1:
		#	if phtml2p==html2p: next
		#	
		#	if '</center><center>' in html2p:
		#		try: resultC=re.compile('<center>\s*([0-9a-zA-Z\s\-]+)\s*</center><center>').findall(html2p)[0];
		#		except: resultC=''
		#		if len(resultC) > 1: CentA=resultC+' - '; 
		#	if '<center> Partea ' in html2p:
		#		s='<center>\s*(Partea .*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; typ=0; 
		#	else:
		#		s='<center>\s*(Server .*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; typ=1; 
		#		#s='<center>\s*(.*?)</center><center>\s*(.*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; typ=1; 
		#	try: results=re.compile(s).findall(html2p);
		#	except: results=''
		iC=len(results) #+iC1; 
		if iC > 0:
				debob(results); 
				#results=sorted(results,key=lambda item: (item[0],item[2]),reverse=False)
				for (url1,domain) in results: #name,
					if "'" in url1: url1=url1.split("'")[0]
					if '"' in url1: url1=url1.split('"')[0]
					if ('://' in url1.lower()) and (not 'http://' in url1.lower()) and (not 'https://' in url1.lower()): url1="http"+url1; 
					elif ('//' in url1.lower()) and (not 'http://' in url1.lower()) and (not 'https://' in url1.lower()): url1="http:"+url1; 
					elif (not '//' in url1.lower()) and (not 'http://' in url1.lower()) and (not 'https://' in url1.lower()): url1="http://"+url1; 
					name=title
					name=name.replace('Partea a IIII-a','Partea IIII').replace('Partea a III-a','Partea III').replace('Partea a II-a','Partea II').replace('Partea I-a','Partea I'); 
					if not addst('mylanguage1','Romanian').lower()=='romanian': 
						name=name.replace('Partea I','Part I'); 
					if ' ~~ ' in wwT: wwT+=CentA+' - '+name
					else: wwT=title+' ~~ '+CentA+' - '+name
					try: URIed=True; import urlresolver; 
					except: URIed=False
					if domain.lower() in ['bit.ly','7est.ro']:
						pass
					elif ("youtube.com/embed/" in url1): 
						try: vID=re.compile('youtube.com/embed/([0-9A-Za-z_\-]+)').findall(url1)[0]
						except:
							try: vID=url1.split("youtube.com/embed/")[-1]
							except: vID=''
						if len(vID) > 0:
							url1='plugin://plugin.video.youtube/?action=play_video&videoid='+vID
							deb('url1',url1)
							cMI=[]; labs={}; pars={'mode':'PlayURL','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							labs['title']=''+CentA+''+name+' - '+(domain.replace('www.','').replace('WWW.','')); 
							try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
							except: pass
					elif (tfalse(addst('internal-vk.com','false'))==True) and (domain.lower() in ['vk.com','vk.me']):
						#quality=str(addst("quality-vk.com","720")); 
						if (URIed==True) and (urlresolver.HostedMediaFile(url1).valid_url()): 
							cMI=[]; labs={}; pars={'mode':'PlayFromHost','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							#labs['title']=cFL(''+CentA+''+name+' - '+domain,'blue'); 
							labs['title']=''+CentA+''+name+' - '+domain+' [UrlResolver]'; 
							#Clabs={'title':title,'year':'','url':m,'destfile':destfile,'img':img,'fanart':fimg,'plot':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
							#cMI=ContextMenu_Hosts(Clabs); 
							try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
							except: pass
						if '&amp;' in url1: url1=url1.replace('&amp;','&')
						if 'http://' in url1: url1=url1.replace('http://','https://')
						#if 'https://' in url1: url1=url1.replace('https://','http://')
						htmlVK=messupText(nolines(nURL(url1)),True,True); deb('length of htmlVK',str(len(htmlVK))); #debob(htmlVK); 
						htmlVK=htmlVK.replace('&amp;','&'); 
						htmlVK=htmlVK.replace('\\/','\/').replace('\/','/'); 
						#debob(htmlVK); 
						#s='url'+quality+'=(\D+://.+?)&'; #deb('s',s); 
						#s='&(\D+)(\d+)=(\D+://.+?)&'; #deb('s',s); 
						s='"(\D+)(\d+)"\s*:\s*"(\D+:.+?)"'; #deb('s',s); 
						#try: rLink=re.compile(s).findall(htmlVK)[0];
						try: rLink=re.compile(s).findall(htmlVK);
						except: rLink=[]
						if len(rLink) > 0:
							s='&(\D+)(\d+)=(\D+://.+?)&';
							#s='"(\D+)(\d+)"\s*:\s*"(\D+:.+?)"'; #deb('s',s); 
							try: rLink=re.compile(s).findall(htmlVK);
							except: rLink=[]
						if len(rLink) > 0:
							pLink=""; debob(rLink); 
							rLink=sorted(rLink,key=lambda item: (item[1],item[0]),reverse=False)
							rLink=sorted(rLink,key=lambda item: (item[0]),reverse=True)
							for rW,rQ,rL in rLink:
								if (rW in ['url','cache']) and (not pLink==rL):
									quality=rW+' '+rQ; 
									cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':rL,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
									#labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','green'); 
									labs['title']=''+CentA+''+name+' - '+domain+' ['+quality+']'; 
									try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
									except: pass
									pLink=""+rL
						if "This video has been removed from public access." in htmlVK:
									deb(domain,"This video has been removed from public access.")
									try: _addon.add_directory({'mode':''},{'title':''+domain+' - This video has been removed from public access.'},is_folder=False)
									except: pass
					elif domain.lower() in ['api.video.mail.ru','videoapi.my.mail.ru']:
						debob(['domain',domain,'url1',url1])
						if (('://videoapi.my.mail.ru/videos/embed/gmail.com/' in url1.lower()) or ('://videoapi.my.mail.ru/videos/embed/list/' in url1.lower()) or ('://videoapi.my.mail.ru/videos/embed/mail/' in url1.lower())) and ('/_myvideo/' in url1.lower()):
							quality=str(addst("quality-api.video.mail.ru","HD")).upper(); 
							### 		http://api.video.mail.ru/videos/embed/gmail.com/clicksud.com/_myvideo/601
							### sd	http://api.video.mail.ru/file/video/v/gmail.com/clicksud.com/_myvideo/601
							### md http://api.video.mail.ru/file/video/hv/gmail.com/clicksud.com/_myvideo/601
							#if   quality=='HD': url1=url1.replace('.html','').replace('/videos/embed/gmail.com/','/file/video/hv/gmail.com/'); 		#HD
							#elif quality=='MD': url1=url1.replace('.html','').replace('/videos/embed/gmail.com/','/file/video/hv2/gmail.com/'); 	#MD
							#elif quality=='SD': url1=url1.replace('.html','').replace('/videos/embed/gmail.com/','/file/video/v/gmail.com/'); 		#SD
							cookyRu=art('cookies.mailru.txt')
							cookyRu2=art('cookies.mailru2.txt')
							url1=url1.replace('https://','http://')
							
							debob(['url1',url1])
							#_SaveFile(cookyRu,'#LWP-Cookies-2.0')
							##htmlMAILruE=messupText(nolines(nURL(url1,cookie_file=cookyRu,save_cookie=True)),True,True); 
							#htmlMAILruE,netRu=nURL(url1,cookie_file=cookyRu,save_cookie=True,ReturnObj=True); 
							#htmlMAILruE,netRu=nURL(url1,cookie_file=cookyRu,load_cookie=True,save_cookie=True,ReturnObj=True); 
							
							#htmlMAILruE=messupText(nolines(htmlMAILruE),True,True); 
							#deb('length of htmlMAILruE',str(len(htmlMAILruE))); #debob(htmlMAILru); 
							#CookiesMailRu=_OpenFile(cookyRu)
							#CookiesMailRu11=str(netRu.get_cookies())
							#debob(['CookiesMailRu11',CookiesMailRu11])
							
							url1=url1.replace('.html','.json').replace('/videos/embed/','/videos/')
							
							debob(['url1',url1])
							#_SaveFile(cooky,'')
							_SaveFile(cookyRu2,'#LWP-Cookies-2.0')
							#htmlMAILru=nURL(url1,cookie_file=cookyRu2,save_cookie=True)
							htmlMAILru,netRu2=nURL(url1,cookie_file=cookyRu2,save_cookie=True,ReturnObj=True)
							htmlMAILru,netRu2=nURL(url1,cookie_file=cookyRu2,load_cookie=True,save_cookie=True,ReturnObj=True)
							
							htmlMAILru=messupText(nolines(htmlMAILru),True,True); 
							deb('length of htmlMAILru',str(len(htmlMAILru))); #debob(htmlMAILru); 
							CookiesMailRu2=_OpenFile(cookyRu2)
							CookiesMailRu22=str(netRu2.get_cookies())
							debob(['CookiesMailRu22',CookiesMailRu22])
							
							try: 
								VideoKeyMailRu=str(re.compile("(?: name='video_key', value='| name=\"video_key\", value=\")([0-9A-Za-z]+)(?:'|\")").findall(CookiesMailRu22)[0])
							except: VideoKeyMailRu=''
							debob(['VideoKeyMailRu',VideoKeyMailRu])
							
							try: sourcesMailRu=re.compile('{"key":\s*"(\d+\D*)",\s*"url":\s*"(\D+://.*?)",\s*"seekSchema":\s*\d+}').findall(htmlMAILru)
							except: sourcesMailRu=[]
							if len(sourcesMailRu) > 0:
								for resMailRu,srcMailRu in sourcesMailRu:
										debob([resMailRu,srcMailRu])
										#srcMailRu+=' timeout=20'
										#srcMailRu+='|Cookie=%s'%(CookiesMailRu)
										if len(VideoKeyMailRu) > 0:
											#srcMailRu+='|Cookie=video_key%3D%s'%(urllib.quote_plus(VideoKeyMailRu))
											#srcMailRu+='|Cookie=video_key%3D%s'%(urllib.quote_plus(str(VideoKeyMailRu)))
											srcMailRu+='|Cookie=%s'%(urllib.quote_plus('video_key='+str(VideoKeyMailRu)))
											
										#srcMailRu+='|Cookie=%s'%('video_key%3Da57a3496b3c9aa76abfbafbe22955e1d76cb9e06')
										#srcMailRu+='|Cookie=%s'%(urllib.quote_plus(CookiesMailRu3))
										debob(['srcMailRu',srcMailRu])
										cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':srcMailRu,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
										#labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','orange'); 
										labs['title']=''+CentA+''+name+' - '+domain+' ['+resMailRu+']'; 
										try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
										except: pass
						elif ('http://api.video.mail.ru/videos/embed/mail/' in url1.lower()) or ('http://videoapi.my.mail.ru/videos/embed/mail/' in url1.lower()):
							quality=str(addst("quality-api.video.mail.ru","HD")).upper(); 
							if   quality=='HD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/hv/mail/'); 		#HD
							elif quality=='MD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/hv2/mail/'); 	#MD
							elif quality=='SD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/v/mail/'); 		#SD
							cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							#labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','orange'); 
							labs['title']=''+CentA+''+name+' - '+domain+' ['+quality+']'; 
							try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
							except: pass
						elif ('http://api.video.mail.ru/videos/embed/gmail.com' in url1.lower()) or ('http://videoapi.my.mail.ru/videos/embed/gmail.com' in url1.lower()):
							quality=str(addst("quality-api.video.mail.ru","HD")).upper(); 
							## 		http://api.video.mail.ru/videos/embed/gmail.com/clicksud.com/_myvideo/601
							## sd	http://api.video.mail.ru/file/video/v/gmail.com/clicksud.com/_myvideo/601
							## md http://api.video.mail.ru/file/video/hv/gmail.com/clicksud.com/_myvideo/601
							if   quality=='HD': url1=url1.replace('.html','').replace('/videos/embed/gmail.com/','/file/video/hv/gmail.com/'); 		#HD
							elif quality=='MD': url1=url1.replace('.html','').replace('/videos/embed/gmail.com/','/file/video/hv2/gmail.com/'); 	#MD
							elif quality=='SD': url1=url1.replace('.html','').replace('/videos/embed/gmail.com/','/file/video/v/gmail.com/'); 		#SD
							cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							#labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','orange'); 
							labs['title']=''+CentA+''+name+' - '+domain+' ['+quality+']'; 
							try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
							except: pass
						else:
							cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							labs['title']=''+CentA+''+name+' - '+domain+' ['+'Not Supported'+']'; 
							try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
							except: pass
					elif (URIed==True) and (urlresolver.HostedMediaFile(url1).valid_url()): 
						#if '&amp;' in url1: url1=url1.replace('&amp;','&')
						cMI=[]; labs={}; pars={'mode':'PlayFromHost','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
						#labs['title']=cFL(''+CentA+''+name+' - '+domain,'blue'); 
						labs['title']=''+CentA+''+name+' - '+(domain.replace('www.','').replace('WWW.','')); 
						#Clabs={'title':title,'year':'','url':m,'destfile':destfile,'img':img,'fanart':fimg,'plot':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
						#cMI=ContextMenu_Hosts(Clabs); 
						try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
						except: pass
					else:
						#cMI=[]; labs={}; pars={'site':site,'mode':'PlayFromCHost','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':title+" ~~ "+name}
						##cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':url1,'title':title,'studio':name,'img':img,'fimg':fimg}
						#labs['title']=cFL(''+CentA+''+name+' - '+domain,'red'); 
						debob('Host domain not currently supported.'); debob([name,url1,domain]); 
						#try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC)
						#except: pass
			#phtml2p=""+html2p; 
	set_view('list',view_mode=addst('links-view')); eod()

def GetMedia(Url,title,imdb_id,img,fimg,stitle,etitle,enumber,snumber,enumber2,wwT=''):
	if len(snumber)==0: snumber='0'; 
	if len(Url)==0: return
	if (mainSite not in Url) and (mainSite2 not in Url): Url=mainSite+Url; 
	###
	_addon.addon.setSetting(id="LastShowListedURL", value=Url)
	_addon.addon.setSetting(id="LastShowListedNAME", value=title)
	_addon.addon.setSetting(id="LastShowListedIMG", value=img)
	_addon.addon.setSetting(id="LastShowListedFANART", value=fimg)
	_addon.addon.setSetting(id="LastShowListedIMDBID", value=imdb_id)
	_addon.addon.setSetting(id="LastShowListedwwT", value=wwT)
	###
	deb('imdb_id',imdb_id); deb('title',title); deb('Url',Url); html=messupText(nolines(nURL(Url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	if len(html)==0: return
	s="<script language='JavaScript' type='text/javascript' src='(/js_content.php.h=[0-9a-zA-Z]+)'></script>"; 
	try: content_url=re.compile(s).findall(html)[0]; 
	except: content_url=''; 
	if (mainSite not in content_url) and (mainSite2 not in content_url): content_url=mainSite+content_url; 
	deb('url for list of links',content_url); html=messupText(nolines(nURL(content_url)),True,True); deb('length of html',str(len(html))); #debob(html); 
	html=html.replace('</iframe>','</_iframe></iframe_>').replace("='","= '</iframe_>")#.replace('</center><center>','</__center__><center>')
	s='</iframe_>.*?</_iframe>'; 
	try: html2p1=re.compile(s).findall(html);
	except: html2p1=''
	iC1=len(html2p1); 
	if iC1 > 0:
		aSortMeth(xbmcplugin.SORT_METHOD_TITLE); 
		phtml2p=""; CentA=''; #html2p1=sorted(html2p1); 
		for html2p in html2p1:
			if phtml2p==html2p: next
			
			if '</center><center>' in html2p:
				try: resultC=re.compile('<center>\s*([0-9a-zA-Z\s\-]+)\s*</center><center>').findall(html2p)[0];
				except: resultC=''
				if len(resultC) > 1: CentA=resultC+' - '; 
			if '<center> Partea ' in html2p:
				s='<center>\s*(Partea .*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; typ=0; 
			else:
				s='<center>\s*(Server .*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; typ=1; 
				#s='<center>\s*(.*?)</center><center>\s*(.*?)</center>\s*<iframe .*?src="(\D+://(.+?)/.+?)"'; typ=1; 
			try: results=re.compile(s).findall(html2p);
			except: results=''
			iC=len(results)+iC1; 
			if iC > 0:
				debob(results); 
				#results=sorted(results,key=lambda item: (item[0],item[2]),reverse=False)
				for (name,url1,domain) in results:
					debob([name,url1,domain]); 
					if (not "http://" in url1) and (not "https://" in url1):
						if (not "://" in url1) and ("//" in url1):
							url1="http:"+url1
					name=name.replace('Partea a IIII-a','Partea IIII').replace('Partea a III-a','Partea III').replace('Partea a II-a','Partea II').replace('Partea I-a','Partea I'); 
					if not addst('mylanguage1','Romanian').lower()=='romanian': 
						name=name.replace('Partea I','Part I'); 
					if ' ~~ ' in wwT: wwT+=CentA+' - '+name
					else: wwT=title+' ~~ '+CentA+' - '+name
					try: URIed=True; import urlresolver; 
					except: URIed=False
					if domain in ['api.video.mail.ru']:
						if 'http://api.video.mail.ru/videos/embed/mail/' in url1:
							quality=str(addst("quality-api.video.mail.ru","HD")).upper(); 
							if   quality=='HD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/hv/mail/'); 		#HD
							elif quality=='MD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/hv2/mail/'); 	#MD
							elif quality=='SD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/v/mail/'); 		#SD
							cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							#labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','orange'); 
							labs['title']=''+CentA+''+name+' - '+domain+' ['+quality+']'; 
						try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
						except: pass
					
					elif domain in ['videoapi.my.mail.ru']:
						if '://videoapi.my.mail.ru/videos/embed/gmail.com/clicksud.com/_myvideo/' in url1:
							quality=str(addst("quality-api.video.mail.ru","HD")).upper(); 
							#if   quality=='HD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/hv/mail/'); 		#HD
							#elif quality=='MD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/hv2/mail/'); 	#MD
							#elif quality=='SD': url1=url1.replace('.html','').replace('/videos/embed/mail/','/file/video/v/mail/'); 		#SD
							url1=url1.replace('https://','http://')
							url1=url1.replace('.html','.json').replace('/videos/embed/','/videos/')
							
							htmlMAILru=messupText(nolines(nURL(url1)),True,True); deb('length of htmlMAILru',str(len(htmlMAILru))); #debob(htmlMAILru); 
							#accidMailRu=re.compile('accid\s*=\s*"(.*?)"').findall(htmlMAILru)[0]
							#wmodeMailRu=re.compile('wmode\s*=\s*"(.*?)"').findall(htmlMAILru)[0]
							#providerIdMailRu=re.compile('providerId\s*=\s*"(.*?)"').findall(htmlMAILru)[0]
							#cssVideoRetinaVersionMailRu=re.compile('cssVideoRetinaVersion\s*=\s*"(.*?)"').findall(htmlMAILru)[0]
							##externalLocationMailRu=re.compile('externalLocation\s*=\s*"(.*?)"').findall(htmlMAILru)[0]
							sourcesMailRu=re.compile('{"key":\s*"(\d+\D*)",\s*"url":\s*"(\D+://.*?)",\s*"seekSchema":\s*\d+}').findall(htmlMAILru)
							#MailRu=re.compile('').findall(htmlMAILru)[0]
							
							for resMailRu,srcMailRu in sourcesMailRu:
								debob([resMailRu,srcMailRu])
								
								cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':srcMailRu,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
								##labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','orange'); 
								#labs['title']=''+CentA+''+name+' - '+domain+' ['+quality+']'; 
								labs['title']=''+CentA+''+name+' - '+domain+' ['+resMailRu+']'; 
								
								try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
								except: pass
					
					elif (tfalse(addst('internal-vk.com','false'))==True) and (domain.lower() in ['vk.com','vk.me']):
						#quality=str(addst("quality-vk.com","720")); 
						if (URIed==True) and (urlresolver.HostedMediaFile(url1).valid_url()): 
							cMI=[]; labs={}; pars={'mode':'PlayFromHost','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
							#labs['title']=cFL(''+CentA+''+name+' - '+domain,'blue'); 
							labs['title']=''+CentA+''+name+' - '+domain+' [UrlResolver]'; 
							#Clabs={'title':title,'year':'','url':m,'destfile':destfile,'img':img,'fanart':fimg,'plot':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
							#cMI=ContextMenu_Hosts(Clabs); 
							try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
							except: pass
						if '&amp;' in url1: url1=url1.replace('&amp;','&')
						if 'http://' in url1: url1=url1.replace('http://','https://')
						#if 'https://' in url1: url1=url1.replace('https://','http://')
						htmlVK=messupText(nolines(nURL(url1)),True,True); deb('length of htmlVK',str(len(htmlVK))); #debob(htmlVK); 
						#s='url'+quality+'=(\D+://.+?)&'; #deb('s',s); 
						#s='&(\D+)(\d+)=(\D+://.+?)&'; #deb('s',s); 
						s='"(\D+)(\d+)"\s*:\s*"(\D+:.+?)"'; #deb('s',s); 
						htmlVK=htmlVK.replace('&amp;','&'); 
						htmlVK=htmlVK.replace('\\/','\/').replace('\/','/'); 
						#debob(htmlVK); 
						#try: rLink=re.compile(s).findall(htmlVK)[0];
						try: rLink=re.compile(s).findall(htmlVK);
						except: rLink=''
						if len(rLink) > 0:
							pLink=""; debob(rLink); 
							rLink=sorted(rLink,key=lambda item: (item[1],item[0]),reverse=False)
							rLink=sorted(rLink,key=lambda item: (item[0]),reverse=True)
							for rW,rQ,rL in rLink:
								if (rW in ['url','cache']) and (not pLink==rL):
									quality=rW+' '+rQ; 
									cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':rL,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
									#labs['title']=cFL(''+CentA+''+name+' - '+domain+' ['+quality+']','green'); 
									labs['title']=''+CentA+''+name+' - '+domain+' ['+quality+']'; 
									try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
									except: pass
									pLink=""+rL
						if "This video has been removed from public access." in htmlVK:
									deb(domain,"This video has been removed from public access.")
									try: _addon.add_directory({'mode':''},{'title':''+domain+' - This video has been removed from public access.'},is_folder=False)
									except: pass
					elif (URIed==True) and (urlresolver.HostedMediaFile(url1).valid_url()): 
						#if '&amp;' in url1: url1=url1.replace('&amp;','&')
						cMI=[]; labs={}; pars={'mode':'PlayFromHost','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':wwT,'imdb_id':imdb_id }
						#labs['title']=cFL(''+CentA+''+name+' - '+domain,'blue'); 
						labs['title']=''+CentA+''+name+' - '+(domain.replace('www.','').replace('WWW.','')); 
						#Clabs={'title':title,'year':'','url':m,'destfile':destfile,'img':img,'fanart':fimg,'plot':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
						#cMI=ContextMenu_Hosts(Clabs); 
						try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC,fanart=fimg,img=img)
						except: pass
					else:
						#cMI=[]; labs={}; pars={'site':site,'mode':'PlayFromCHost','url':url1,'title':title,'studio':CentA+''+name,'img':img,'fimg':fimg,'wwT':title+" ~~ "+name}
						##cMI=[]; labs={}; pars={'site':site,'mode':'PlayURL','url':url1,'title':title,'studio':name,'img':img,'fimg':fimg}
						#labs['title']=cFL(''+CentA+''+name+' - '+domain,'red'); 
						debob('Host domain not currently supported.'); debob([name,url1,domain]); 
						#try: _addon.add_directory(pars,labs,is_folder=False,contextmenu_items=cMI,total_items=iC)
						#except: pass
			phtml2p=""+html2p; 
	set_view('list',view_mode=addst('links-view')); eod()

def TagAnimeName(animename):
	#return animename
	try:
		s2=[' sezonul','Sezonul ','Sezon','sezon',' episodul','Episod',' online',' (','(',' subtitrat']
		for s in s2:
			try: 
				if s in animename: animename=animename.split(s)[0]
			except: pass
			if s in animename: animename=animename.replace(s,'')
		return animename
	except: return animename

def ListShows(Url,title='',imdb_id='',img='',fimg='',stitle='',etitle='',enumber='',snumber='',enumber2='',wwT=''):
	if len(Url)==0: return
	if (not mainSite in Url) and (not mainSite2 in Url): 
		if "/feeds/" in Url.lower(): Url=mainSite2+Url; 
		else: Url=mainSite+Url; 
	deb('Url',Url); 
	cooky=art('cookies.page.txt'); 
	_SaveFile(cooky,''); 
	#html=messupText(nolines(nURL(Url)),True,True); 
	html=messupText(nolines(nURL(Url,cookie_file=cooky,load_cookie=True,save_cookie=True)),True,True); 
	deb('length of html',str(len(html))); #debob(html); 
	
	
	if len(html)==0: return
	html=html.replace("\n","").replace("\r","").replace("\a","").replace("\t","")
	if   "<!DOCTYPE html>" in html: InitPageType="html"
	elif "<?xml version='1.0' encoding='UTF-8'?>" in html: InitPageType="xml"
	else: InitPageType="html"
	deb("InitPageType",InitPageType); 
	if InitPageType=="html":
		s="<a class='blog-pager-older-link' href='(\D+://.+?)' id='Blog\d*_blog-pager-older-link'"
		try: NextPageURL=re.compile(s).findall(html.replace("'>","'\n>"))[0]; 
		except: NextPageURL=''; 
	elif InitPageType=="xml":
		#s=""
		#try: NextPageURL=re.compile(s).findall(html.replace("</entry>","'</entry\n>"))[0]; 
		#except: NextPageURL=''; 
		NextPageURL=''; 
	## ### ## 
	if InitPageType=="html":
		s =""
		#s+="<div class='post-outer'>\s*"; 
		#s+="<article class='post \D+' id='\d+' itemscope='itemscope' itemtype='http://schema.org/BlogPosting'>\s*"
		#s+="<h2 class='post-title entry-title' itemprop='name headline'>\s*"; 
		###
		#s+="<a href='(\D+://.+?)' itemprop='url'>\s*(.+?)\s*</a>\s*</h2>\s*<div.*?>\s*"; 
		#s+="<textarea id='postData-\d+' style='.*?'>\s*(?:<h2.*?>\s*.+?\s*</h2>\s*)?"; 
		#s+='.*?\s*(?:<div.*?>)?\s*.*?'; 
		#s+='<img alt=".+?" src="(\D+://.+?)"'; # title=".+?" .*?/><b>.+?</b><br />\s*<hr />\s*'; 
		###
		s+="<a href='(\D+://.+?)' itemprop='url'>\s*(.+?)\s*</a>\s*</h\d+>\s*<div.*?>\s*"; 
		s+="<textarea id='postData-\d+' style='.*?'>\s*(?:<h\d+.*?>\s*.+?\s*</h\d+>\s*)?"; 
		s+='.*?\s*(?:<div.*?>)?\s*.*?'; 
		s+='<img alt=".+?" src="(\D+://.+?)"'; # title=".+?" .*?/><b>.+?</b><br />\s*<hr />\s*'; 
		#s+=""; 
		#s+=""; 
		#s+=""; 
		#s+=""; 
		#if mainSite+'/?s=' in Url: s='<div class="span3" style="width:\d+px;margin-left:1%;margin-bottom:10px;"><div class="item"><a href="http://www.justanimestream.net/anime-series/gantz-ii-perfect-answer/" data-toggle="tooltip" data-placement="right" data-original-title="Gantz II: Perfect Answer"><figure><img src="/bimages/gantz-ii-perfect-answer.jpg" class="animethumbs" alt="Gantz II: Perfect Answer" width="125px" height="190px"/><div class="overlay"><i class="icon-play"></i></div></figure><article><h5>(.+?)</h5></article></a></div></div>'; 
		### url,name,img
		try: matches=re.compile(s).findall(html.replace('</div></div>','</div>\n</div>').replace('</tr><tr','</tr>\n\r\a<tr').replace('<table ','<table\n\r\a ').replace('<article ','<article\n\r\a ').replace('<th ','<th\n\r\a ')); deb('# of matches found (html)',str(len(matches))); #debob(matches)
		except: matches=[]; 
		if len(matches)==0:
			s ='<td.+?>(?:<div.*?>)?\s*'
			s+='(?:<span.*?>)?(?:<b>)?(?:<u>)?(?:<span.*?>)?'
			s+='<a href="(\D+://.+?)".*?>'
			s+='(?:<span.*?>)?\s*(?:<b>)?\s*(.+?)\s*(?:</b>)?\s*(?:</span>)?</a>(?:</span>)?\s*(?:<u>)?(?:</b>)?(?:</span>)?(?:</div>)?\s*(</td)'; 
			#try: 
			matches=re.compile(s,re.IGNORECASE).findall(html.replace('</div></div>','</div>\n</div>').replace('</tr><tr','</tr>\n\r\a<tr').replace('<tr ','<tr\n\r\a ').replace('<table ','<table\n\r\a ').replace('<article ','<article\n\r\a ').replace('<th ','<th\n\r\a ').replace('</td>','</td\n\r\a>')); deb('# of matches found (html)*',str(len(matches))); #debob(matches)
			#except: matches=[]; 
		if len(matches)==0:
			s='<td>(?:<div.*?>)?\s*(?:<span.*?>)?(?:<b>)?(?:<u>)?(?:<span.*?>)?<a href="(\D+://.+?)".*?>(?:<span.*?>)?\s*(?:<b>)?\s*(.+?)\s*(?:</b>)?\s*(?:</span>)?</a>(?:</span>)?\s*(?:<u>)?(?:</b>)?(?:</span>)?(?:</div>)?\s*(</td)'; 
			try: matches=re.compile(s).findall(html.replace('</div></div>','</div>\n</div>').replace('</tr><tr','</tr>\n\r\a<tr').replace('<tr ','<tr\n\r\a ').replace('<table ','<table\n\r\a ').replace('<article ','<article\n\r\a ').replace('<th ','<th\n\r\a ').replace('</td>','</td\n\r\a>')); deb('# of matches found (html)*',str(len(matches))); #debob(matches)
			except: matches=[]; 
		if (len(matches)==0) or ('/filme-online-subtitrate.html' in Url) or ('/emisiuni-tv-online.html' in Url) or ('/seriale-online.html' in Url):
			#s='<td>(?:<div.*?>)?\s*(?:<span.*?>)?(?:<b>)?(?:<u>)?(?:<span.*?>)?<a href="(\D+://.+?)".*?>(?:<span.*?>)?\s*(?:<b>)?\s*(.+?)\s*(?:</b>)?\s*(?:</span>)?</a>(?:</span>)?\s*(?:<u>)?(?:</b>)?(?:</span>)?(?:</div>)?\s*(</td)'; 
			s='<td><a href="(\D+://.+?)"\s*(?:target="_blank")?>(?:<b>)?\s*\(.+?)s*(?:</b>)?</a>(</td)'; 
			try: matches=re.compile(s).findall(html.replace('</div></div>','</div>\n</div>').replace('</tr><tr','</tr>\n\r\a<tr').replace('<tr ','<tr\n\r\a ').replace('<table ','<table\n\r\a ').replace('<article ','<article\n\r\a ').replace('<th ','<th\n\r\a ').replace('</td>','</td\n\r\a>')); deb('# of matches found (html)*',str(len(matches))); #debob(matches)
			except: matches=[]; 
	elif InitPageType=="xml":
		s ="<entry>.*?"
		s+="<title type='text'>.+?</title>"
		s+=".*?<link rel='alternate' type='text/html' href='(\D+://.+?)' title='(.+?)'/>"
		s+=""
		s+='.*?<media:thumbnail\s*.*?\s+url="(\D+://.+?)".*?>'
		s+=""
		s+=""
		s+=".*?</entry"
		try: matches=re.compile(s).findall(html.replace("</entry>","'</entry\n>")); deb('# of matches found (xml)',str(len(matches))); #debob(matches)
		except: matches=[]; 
	if (len(matches)==0) and (InitPageType=="html"):
		#s ='<td><b><a href="(\D+://.+?/.+?)" target="_blank">(.+?)</a>(</b>)</td'; 
		#s ='<td>[</b>]*<a href="(\D+://.+?/.+?)"\s*(?:target="_blank"|)?>(.+?)</a>[</b>]*(</td)'; 
		#s ='<td>[</b>]*<a href="(\D+://.+?/.+?)".*?>(.+?)</a>[</b>]*(</td)'; 
		s ='<td><b><a href="(.+?)"\s*(?:target="_blank")?>(.+?)</a></b>(</td)'; 
		#s+=""; 
		try: matches=re.compile(s).findall(html.replace('<td><a ','<td><b><a ').replace('</a></td','</a></b></td').replace('<td>','\n\r\a<td>').replace('</td>','</td  \n\r\a>  ').replace('</tr>','</tr  \n\r\a>  ')); deb('# of matches found',str(len(matches))); #debob(matches)
		except: matches=[]; 
	if (len(matches)==0) and (InitPageType=="html"):
		debob("No item matches, checking for videos."); 
		s="<iframe .*?src=(?:\"|')((?:\D+\:)?//(.+?)/.+?)(?:\"|')\s*.*?>\n*</iframe"
		try: iFrameMatches=re.compile(s,re.IGNORECASE).findall(html.replace("><","'>\n<").replace("</iframe>","'</iframe\n>")); debob(['iFrameMatches',iFrameMatches])
		except: iFrameMatches=[]; 
		if len(iFrameMatches) > 0:
			CheckMedia(iFrameMatches,html,Url,title,imdb_id,img,fimg,stitle,etitle,enumber,snumber,enumber2,wwT=''); 
			return
	elif len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if InitPageType=="html":
			#s='<img alt=".*?"(?: height="\d+")?(?: width="\d+")? src="(\D+://.*?blogspot.com/.+?)".*?></div>'
			#s='<img alt=".*?" (?:height="\d+" )?src="(\D+://.*?blogspot.com/.+?)".*?></div'
			s='<img alt=".*?" src="(\D+://.*?blogspot.com/.+?)".*?></div>'
			#s='<img alt=".*?" src="(\D+://.*?blogspot.com.+?)".*?></div>'
			try: imatch=re.compile(s).findall(html)[0]; deb('imatch',imatch); 
			except: imatch=''; 
			if (len(imatch)==0) or (len(imatch) > 50) or (">" in imatch) or ("'" in imatch) or ('"' in imatch):
				s='<img alt=".*?" height="\d+" src="(\D+://.*?blogspot.com/.+?)".*?></div'
				try: imatch=re.compile(s).findall(html)[0]; deb('imatch',imatch); 
				except: imatch=''; 
			if (len(imatch)==0) or (len(imatch) > 50) or (">" in imatch) or ("'" in imatch) or ('"' in imatch):
				s="<link href='(.+?)' rel='image_src'/>"
				try: imatch=re.compile(s).findall(html)[0]; deb('imatch',imatch); 
				except: imatch=''; 
		else: imatch=''; 
		if (len(imatch)==0) or (len(imatch) > 50) or (">" in imatch) or ("'" in imatch) or ('"' in imatch): imatch=''
		deb('imatch',imatch)
		#if "' class='previouspostslink'>" in html:
		#	try: PrEVIOUS= html.split("' class='previouspostslink'>")[0].split("<a href='")[-1]; #re.compile("<a href='(.+?)' class='previouspostslink'>").findall(html)[0]; 
		#	except: PrEVIOUS=Url; 
		#	deb('previous',PrEVIOUS); _addon.add_directory({'mode':'ListShows','url':PrEVIOUS,'site':site,'section':section},{'title':cFL('<< Previous','green')+'  '+PrEVIOUS.replace(mainSite,'').replace(mainSite2,'')},is_folder=True,fanart=fanartSite,img=psgn('img_prev'))
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		debob(matches); 
		for (url,name,img) in matches:
			if (img.lower()=="</b>") or (img.lower()=="</td"): img=imatch; enMeta=False; 
			elif len(img)==0: img=imatch; 
			name=name.replace('<b>','').replace('</b>','').replace('<B>','').replace('</B>',''); 
			debob([url,name,img]); 
			name1=''+name; 
			if 'episodul' in name1.lower(): TyP='tv'
			elif 'episod' in name1.lower(): TyP='tv'
			elif 'sezonul' in name1.lower(): TyP='tv'
			elif 'sezon' in name1.lower(): TyP='tv'
			elif 'tv' in name1.lower(): TyP='tv'
			elif ' online subtitrat' in name1.lower(): TyP='movie'
			elif 'movie' in name1.lower(): TyP='movie'
			else: TyP='movie'
			name=name.replace('sezonul ',' s').replace('episodul ',' e').replace(' ONLINE SUBTITRAT','').replace(' online subtitrat','').replace(' - ','').replace(' -','').replace('Sezonul ',' s').replace(' subtitrat','').replace('Sezon ',' s').replace('sezon ',' s').replace(' ONLINE','').replace('Finala',' Finala').replace('Episodul ',' e').replace('EPISODUL ',' e').replace('EPISOD ',' e').replace('Episod ',' e').replace('  ',' ')
			if ' online' in name: 
				try: name=name.split(' online')[0]
				except: name=name.replace(' online','')
			name2=""+name; 
			#if '(' in name2: 
			#	try: Year=name2.split('(')[1].split(')')[0]
			#	except: Year=''
			#	name2=name2.split('(')[0]
			#else: Year=''
			Year=''
			if ' - ' in name2: name2=name2.split(' - ')[0]
			img=FixImage(img); cMI=[]; img=img.replace(' ','%20'); fimg=fanartSite; deb('img',img); Genres2=""; g="<a href='http://www.animefate.com/.genre=.+?'>\s*(.+?)\s*</a>"; plot=""; labs={}; 
			genres=""; 
			#try: Genres1=re.compile(g).findall(genres); debob(Genres1); 
			#except: Genres1=""; 
			#for g in Genres1: Genres2+="["+g+"] "; 
			#Genres2=str(Genres1); 
			wwT=name+" ~~ "; 
			#wwT=name2+" ~~ "; 
			try:
				if visited_check(wwT)==True: ww=7
				#if visited_check2(wwT)==True: ww=7
				else: ww=6
			except: ww=6
			if enMeta==True: 
				if TyP=='movie':
					#try: labs=grab.get_meta('movie',TagAnimeName(name2),overlay=ww); debob(labs); 
					try: labs=grab.get_meta('movie',TagAnimeName(name1)); debob(labs); 
					except: pass
				else:
					#try: labs=grab.get_meta('tvshow',TagAnimeName(name2),overlay=ww); debob(labs); 
					try: labs=grab.get_meta('tvshow',TagAnimeName(name1)); debob(labs); 
					except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except:
					try:
						if len(labs['backdrop_url']) > 0: fimg=labs['backdrop_url']; 
					except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=''+name; labs[u'year']=''; 
			try:
				if len(labs['imdb_id'])==0: labs[u'imdb_id']=''
			except: labs[u'imdb_id']=''
			#plot+=CR+"Genres:  [COLOR purple]"+Genres2+"[/COLOR]"; #plot+="[CR]Year: [COLOR purple]"+year+"[/COLOR]"; #plot+="[CR]Status: [COLOR purple]"+status+"[/COLOR]"; #plot+="[CR]Number of Episodes: [COLOR purple]"+NoEps+"[/COLOR]"; 
			#pars={'mode':'ListEpisodes','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site,'section':section}; 
			pars={'mode':'ListShows','url':url,'title':name,'imdb_id':labs[u'imdb_id'],'img':img,'fimg':fimg,'site':site,'section':section,'wwT':wwT}; 
			labs[u'plot']=plot+CR+cFL(labs[u'plot'],'mediumpurple'); labs[u'title']=AFColoring(name); 
			#Clabs=labs; 
			labs[u'title']=wwA(labs[u'title'],ww); 
			Clabs={'title':name,'year':labs[u'year'],'url':url,'commonid':labs[u'imdb_id'],'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs,TyP); 
			except: pass
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC,context_replace=True)
			except: pass
		if len(NextPageURL) > 0:
			_addon.add_directory({'mode':'ListShows','url':NextPageURL,'site':site,'section':section},{'title':cFL('>> Next','green')},is_folder=True,fanart=fanartSite,img=psgn('img_next'))
		#if "' class='nextpostslink'>" in html:
		#	try: NeXT=html.split("' class='nextpostslink'>")[0].split("<a href='")[-1]; #re.compile("</span><a href='("+mainSite+"/.+?/)' class='nextpostslink'>").findall(html)[0]; 
		#	except: NeXT=Url; 
		#	deb('next',NeXT); _addon.add_directory({'mode':'ListShows','url':NeXT,'site':site,'section':section},{'title':cFL('>> Next','green')+'  '+NeXT.replace(mainSite,'').replace(mainSite2,'')},is_folder=True,fanart=fanartSite,img=psgn('img_next'))
		#if "' class='last'>Ultima " in html:
		#	try: LaST=html.split("' class='last'>Ultima ")[0].split("<a href='")[-1]; #re.compile("<a href='("+mainSite+"/.+?/)' class='last'>Last ").findall(html)[0]; 
		#	except: LaST=Url; 
		#	deb('last',LaST); _addon.add_directory({'mode':'ListShows','url':LaST,'site':site,'section':section},{'title':cFL('>> >> Last','green')+'  '+LaST.replace(mainSite,'').replace(mainSite2,'')},is_folder=True,fanart=fanartSite,img=psgn('img_next'))
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()

def LatestShows():
	html=messupText(nolines(nURL(mainSite)),True,True).replace('\n','').replace('\r','').replace('\a','').replace('\t',''); 
	deb('length of html',str(len(html)))
	#s="<h2>Seriale noi online subtitrate</h2><div class='widget-content'><ul>(.*?)</ul>"
	s="<h2>Seriale online nou adaugate</h2><div class='widget-content'><ul>(.*?)</ul>" ## As of feb 2015, this area no longer seems to exist on the site.
	html=re.compile(s).findall(html)[0]
	s="<li><a href='(\D+://.+?/.+?)'>(.+?)\s*(?:\()?(\d\d\d\d)(?:\))?.*?</a></li"
	try: matches=re.compile(s).findall(html.replace('</li>','</li\n>'))
	except: matches=[]
	if len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for url,name,year in matches:
			img=iconSite; fimg=fanartSite; 
			labs={'title':name+' ('+year+')','year':year,'plot':'','imdb_id':''}
			if enMeta==True: 
				try: labs=grab.get_meta('tvshow',name); debob(labs); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except:
					try:
						if len(labs['backdrop_url']) > 0: fimg=labs['backdrop_url']; 
					except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=''+name; labs[u'year']=''; 
			try:
				if len(labs['imdb_id'])==0: labs[u'imdb_id']=''
			except: labs[u'imdb_id']=''
			labs['title']=name+' ('+year+')'
			pars={'mode':'ListShows','url':url,'title':name,'site':site,'section':section}; 
			Clabs={'title':name,'year':year,'url':url,'commonid':labs[u'imdb_id'],'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs,'tv'); 
			except: cMI=[]
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC,context_replace=True)
			except: pass
	set_view('tvshows',view_mode=addst('tvshows-view')); eod()
	
def LatestMovies():
	html=messupText(nolines(nURL(mainSite)),True,True).replace('\n','').replace('\r','').replace('\a','').replace('\t',''); 
	#s="<h2>Ultimele filme adaugate</h2><div class='widget-content'><ul>(.*?)</ul>"
	s="<h2>Ultimele filme recent adaugate</h2><div class='widget-content'><ul>(.*?)</ul>"
	html=re.compile(s).findall(html)[0]
	##s="<li><a href='(.+?/.+?)'>(.+?)\s*(?:\()?(\d\d\d\d)(?:\))?.*?</a></li"
	s ="<li><a href='(.+?/.+?)'>(.+?)"; 
	s+="(?:\s+online\s+\D+)?\s*(?:\()?(\d\d\d\d|)(?:\)?|)?(?:\s+online\s+\D+)?"; 
	s+="\s*</a></li"; 
	try: matches=re.compile(s).findall(html.replace('</li>','</li\n>'))
	except: matches=[]
	#debob(matches); 
	if len(matches) > 0:
		iC=len(matches); enMeta=tfalse(addst("enableMeta","false")); 
		if enMeta==True:
			try: from metahandler import metahandlers; grab=metahandlers.MetaData(preparezip=False); 
			except: debob("filed to import metahandler"); 
		for url,name,year in matches:
			img=iconSite; fimg=fanartSite; 
			if not '://' in url: url='http://'+url
			labs={'title':name+' ('+year+')','year':year,'plot':'','imdb_id':''}
			if enMeta==True: 
				try: labs=grab.get_meta('movie',name); debob(labs); 
				except: pass
				try:
					if len(labs[u'cover_url']) > 0: img=labs[u'cover_url']; 
				except: pass
				try:
					if len(labs[u'backdrop_url']) > 0: fimg=labs[u'backdrop_url']; 
				except:
					try:
						if len(labs['backdrop_url']) > 0: fimg=labs['backdrop_url']; 
					except: pass
			else: labs[u'plot']=''; labs[u'imdb_id']=''; labs[u'title']=''+name; labs[u'year']=''; 
			try:
				if len(labs['imdb_id'])==0: labs[u'imdb_id']=''
			except: labs[u'imdb_id']=''
			if len(str(year)) > 0: labs['title']=name+' ('+year+')'
			else: labs['title']=name
			pars={'mode':'ListShows','url':url,'title':name,'site':site,'section':section}; 
			Clabs={'title':name,'year':year,'url':url,'commonid':labs[u'imdb_id'],'img':img,'fanart':fimg,'plot':labs[u'plot'],'todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}; 
			try: cMI=ContextMenu_Series(Clabs,'movie'); 
			except: cMI=[]
			try: _addon.add_directory(pars,labs,is_folder=True,fanart=fimg,img=img,contextmenu_items=cMI,total_items=iC,context_replace=True)
			except: pass
	set_view('movies',view_mode=addst('tvshows-view')); eod()
	

def Fav_List(site='',section='',subfav=''):
	debob(['test1',site,section,subfav]); 
	favs=fav__COMMON__list_fetcher(site=site,section=section,subfav=subfav); 
	ItemCount=len(favs); 
	debob('test2 - '+str(ItemCount)); 
	if len(favs)==0: myNote('Favorites','None Found'); eod(); return
	favs=sorted(favs,key=lambda item: (item[0],item[1]),reverse=False); 
	debob(favs); 
	for (_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2) in favs:
		debob([_name,_year,_img,_fanart,_Country,_Url,_plot,_Genres,_site,_subfav,_section,_ToDoParams,_commonID,_commonID2]); 
		if _img > 0: img=_img
		else: img=iconSite
		if _fanart > 0: fimg=_fanart
		else: fimg=fanartSite
		debob(['_ToDoParams',_ToDoParams]); #debob(_ToDoParams)
		pars=_addon.parse_query(_ToDoParams)
		try: pars['url']=pars['plugin://plugin.video.clicksud/?url']
		except: pass
		debob(["pars['url']",pars['url']]); 
		#debob(['pars',pars]); 
		pars[u'fimg']=_fanart; pars[u'img']=_img; 
		#if len(_commonID) > 0: pars['imdb_id']=_commonID
		try:
			if len(pars['imdb_id']) > 0: pars['imdb_id']='0'; 
		except: pars['imdb_id']='0'; 
		debob(['pars',pars]); #debob('pars'); debob(pars)
		_title=AFColoring(_name)
		if (len(_year) > 0) and (not _year=='0000'): _title+=cFL('  ('+cFL(_year,'mediumpurple')+')',colorA)
		if len(_Country) > 0: _title+=cFL('  ['+cFL(_Country,'mediumpurple')+']',colorA)
		wwT=_name+" ~~ "; 
		try:
			if visited_check2(wwT)==True: ww=7
			else: ww=6
		except: ww=6
		contextLabs={'title':_name,'year':_year,'img':_img,'fanart':_fanart,'country':_Country,'url':_Url,'plot':_plot,'genres':_Genres,'site':_site,'subfav':_subfav,'section':_section,'todoparams':_ToDoParams,'commonid':_commonID,'commonid2':_commonID2}
		##contextLabs={'title':_name,'year':'0000','url':_url,'img':img,'fanart':fimg,'DateAdded':'','todoparams':_addon.build_plugin_url(pars),'site':site,'section':section}
		contextMenuItems=ContextMenu_Favorites(contextLabs)
		contextMenuItems.append( ('Empty List','XBMC.RunPlugin(%s)' % _addon.build_plugin_url({'mode':'cFavoritesEmpty','site':site,'section':section,'subfav':subfav}) ) )
		#contextMenuItems=[]
		_title=wwA(_title,ww); 
		_addon.add_directory(pars,{'title':_title,'plot':_plot},is_folder=True,fanart=fimg,img=img,total_items=ItemCount,contextmenu_items=contextMenuItems)
		#
	#
	if 'movie' in section.lower(): content='movies'
	else: content='tvshows'
	set_view(content,view_mode=int(addst('tvshows-view'))); eod()


### ############################################################################################################
### ############################################################################################################
def MenuAZ(url):
	#_addon.add_directory({'mode':'ListShows','url':url+'/','site':site,'section':section},{'title':AFColoring('ALL')},is_folder=True,fanart=fanartSite,img=psgn('all')); 
	_addon.add_directory({'mode':'ListShows','url':url+'/0/','site':site,'section':section},{'title':AFColoring('#')},is_folder=True,fanart=fanartSite,img=psgn('0')); 
	for az in MyAlphabet:
		az=az.upper(); _addon.add_directory({'mode':'ListShows','url':url+'/'+az.lower()+'/','site':site,'section':section},{'title':AFColoring(az)},is_folder=True,fanart=fanartSite,img=psgn(az.lower())); 
	set_view('list',view_mode=addst('default-view')); eod()

def DoSearch(title='',Url='/?s='):
	if len(Url)==0: return
	#if mainSite not in Url: Url=mainSite+Url; 
	if (not mainSite in Url) and (not mainSite2 in Url): 
		if "/feeds/" in Url.lower(): Url=mainSite2+Url; 
		else: Url=mainSite+Url; 
	if len(title)==0: title=showkeyboard(txtMessage=title,txtHeader="Search:  ("+site+")")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title); title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','%20'); 
	deb('Searching for',title); ListShows( Url+( title.replace(' ','%20') ) ); 

def MenuGenre():
	html=messupText(nolines(nURL(mainSite)),True,True)#.replace('\n','').replace('\r','').replace('\a','').replace('\t',''); 
	s="<li><a href='(.+?)'\s*(?:target='_blank')?>\s*(.+?)\s*</a></li"
	#s="<li><a href='(.+?)'>\s*(.+?)\s*</a></li"
	MyGenres=re.compile(s).findall(html.replace('</li><li>','</li>\n<li>').replace('<ul><li>','<ul>\n<li>').replace('</li>','</li\n>')); 
	MyGenres.append(["http://www.clicksud.com/2012/11/emisiuni-tv-online.html","Emisiuni tv online"])
	MyGenres.append(["http://www.clicksud.com/2012/11/seriale-online.html","Seriale online subtitrate"])
	#MyGenres.append(["",""])
	if len(MyGenres) > 0:
		for aUrl,aName in MyGenres:
			if aName not in ['CONTACT - FAQ','Rss','Google','Twitter','Facebook','CONTACT - FAQ - CERERI']:
				if '"' in aUrl: aUrl=aUrl.split('"')[0]
				if "'" in aUrl: aUrl=aUrl.split("'")[0]
				i=iconSite
				try:
					_addon.add_directory({'mode':'ListShows','url':aUrl,'site':site,'section':section},{'title':AFColoring(aName)},is_folder=True,fanart=fanartSite,img=i); 
				except: pass
	
	#for aL,azRo,azEn in MyGenres: 
	#	if addst('mylanguage1','Romanian').lower()=='romanian': az=azRo
	#	else: az=azEn
	#	i=psgn(az.lower())
	#	if len(i)==0: i=iconSite
	#	_addon.add_directory({'mode':'ListShows','url':'/'+aL.lower().replace(' ','-')+'/','site':site,'section':section},{'title':AFColoring(az)},is_folder=True,fanart=fanartSite,img=i); 
	set_view('list',view_mode=addst('list-view')); eod()

def MenuYear():
	ThisYear=str(datetime.date.today().year)
	ThisMonth=str(datetime.date.today().month)
	if len(ThisMonth)==1: ThisMonth='0'+ThisMonth
	MyYears=[]
	MyYearsB=['','12/','11/','10/','09/','08/','07/','06/','05/','04/','03/','02/','01/']
	for az in range(1950,int(ThisYear)+1): MyYears.append(str(az))
	for az in MyYears[::-1]: 
		for bz in MyYearsB: 
			i=iconSite #psgn(az.lower())
			if len(i)==0: i=iconSite
			#if (int(az) < int(ThisYear)) or (int(bz) < (int(ThisMonth)+1)):
			DoIT=False; 
			if len(bz)==0: bz2='00'
			else: bz2=bz.replace('/','')
			try:
				if (int(az) < int(ThisYear)) or (int(bz2) < (int(ThisMonth)+1)): DoIT=True
				else: DoIT=False
			except: DoIT=False
			if DoIT==True:
					_addon.add_directory({'mode':'ListShows','url':'/despre/filme-'+az+'/'+bz,'site':site,'section':section},{'title':cFL(az+cFL('/',colorA)+bz.replace('/',cFL('/',colorA)),colorB)},is_folder=True,fanart=fanartSite,img=i); 
	set_view('list',view_mode=addst('list-view')); eod()
def SectionMenu():
	#addstv('firstrun','') ## To reset first-run value for testing ##
	if len(addst('firstrun',''))==0: 
		L=popYN(title=ps('__plugin__'),line1='                                          Selectarea limbii',line2='                                       Language Selection',line3='',n='English',y='Romanian'); #deb("L",str(L)); 
		if str(L)=='1': addstv('mylanguage1','Romanian'); 
		else: addstv('mylanguage1','English'); 
		addstv('firstrun','no'); 
	ThisYear=str(datetime.date.today().year)
	ThisMonth=str(datetime.date.today().month)
	if len(ThisMonth)==1: ThisMonth='0'+ThisMonth
	#_addon.add_directory({'mode':'GetMedia','site':site,'url':'/tremors-4-the-legend-begins-tremors-4-inceputul-legendei-2004-filme-online.html'},{'title':AFColoring('Testing')},is_folder=True,fanart=fanartSite,img=iconSite)
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/'},{'title':RoAFColoring('Toate','ALL')},is_folder=True,fanart=fanartSite,img=psgn('all')) #iconSite)
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/'+ThisYear+'/'},{'title':cFL(RoAF(ThisYear,ThisYear),colorB)},is_folder=True,fanart=fanartSite,img=psgn('this_year')) #iconSite)
	_addon.add_directory({'mode':'ListShows','site':site,'url':'/'+ThisYear+'/'+ThisMonth+'/'},{'title':cFL(RoAF(ThisYear+'/'+ThisMonth,ThisYear+cFL('/',colorA)+ThisMonth),colorB)},is_folder=True,fanart=fanartSite,img=psgn('this_month')) #iconSite)
	_addon.add_directory({'mode':'MenuYear','site':site},{'title':RoAFColoring('Ani','Years')},is_folder=True,fanart=fanartSite,img=psgn('year'))
	
	_addon.add_directory({'mode':'MenuGenre','site':site},{'title':RoAFColoring('Categorii populare','Popular Categories')},is_folder=True,fanart=fanartSite,img=psgn('genre'))
	
	#_addon.add_directory({'mode':'LatestShows','site':site},{'title':RoAFColoring('Seriale noi subtitrate','New Series with Subtitles')},is_folder=True,fanart=fanartSite,img=psgn('latest_series')) ## This section of the site no longer exists.
	_addon.add_directory({'mode':'LatestMovies','site':site},{'title':RoAFColoring('Ultimele filme adaugate','Latest Movies')},is_folder=True,fanart=fanartSite,img=psgn('latest_movies'))
	
	_addon.add_directory({'mode':'Search','site':site,'url':'/feeds/posts/default?max-results=9999&q='},{'title':RoAFColoring('Cautare','Search')},is_folder=True,fanart=fanartSite,img=psgn('search'))
	_addon.add_directory({'mode':'Search','site':site,'url':'/search/label/'},{'title':RoAFColoring('Cautare Eticheta','Search Label')},is_folder=True,fanart=fanartSite,img=psgn('search'))
	
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL('Filme - Movies',colorB)},fanart=fanartSite,img=psgn('favorites 1'))
	_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL('Seriale - TV Shows',colorB)},fanart=fanartSite,img=psgn('favorites 2'))
	
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section             },{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.1.name'),colorB)},fanart=fanartSite,img=psgn('favorites 1'))
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'2'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.2.name'),colorB)},fanart=fanartSite,img=psgn('favorites 2'))
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'3'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.3.name'),colorB)},fanart=fanartSite,img=psgn('favorites 3'))
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'4'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.4.name'),colorB)},fanart=fanartSite,img=psgn('favorites 4'))
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'5'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.5.name'),colorB)},fanart=fanartSite,img=psgn('favorites 5'))
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'6'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.6.name'),colorB)},fanart=fanartSite,img=psgn('favorites 6'))
	#_addon.add_directory({'mode':'FavoritesList','site':site,'section':section,'subfav':'7'},{'title':cFL(ps('WhatRFavsCalled'),colorA)+cFL(addst('fav.tv.7.name'),colorB)},fanart=fanartSite,img=psgn('favorites 7'))
	###
	
	#if (len(addst("LastShowListedURL")) > 0): 
	#	pars={'site':site,'section':section,'mode':'GetMedia','url':addst("LastShowListedURL"),'title':addst("LastShowListedNAME"),'imdb_id':addst("LastShowListedIMDBID"),'img':addst("LastShowListedIMG"),'fimg':addst("LastShowListedFANART"),'wwT':addst("LastShowListedwwT")}; 
	#	title=AFColoring(addst("LastShowListedNAME"))+CR+cFL('[Last Show]',colorA); 
	#	_addon.add_directory(pars,{'title':title},fanart=addst("LastShowListedFANART"),img=addst("LastShowListedIMG"),is_folder=True); 
	
	#if (len(addst("LastEpisodeListedURL")) > 0): 
	#	pars={'site':site,'section':section,'mode':'GetMedia','url':addst("LastEpisodeListedURL"),'title':addst("LastEpisodeListedNAME"),'imdb_id':addst("LastEpisodeListedIMDBID"),'img':addst("LastEpisodeListedIMG"),'fimg':addst("LastEpisodeListedFANART"),'stitle':addst("LastEpisodeListedSTITLE"),'etitle':addst("LastEpisodeListedETITLE"),'e':addst("LastEpisodeListedEpNo"),'s':addst("LastEpisodeListedSNo"),'e2':addst("LastEpisodeListedEpNo2")}; 
	#	title=AFColoring(addst("LastEpisodeListedNAME"))+CR+cFL('[Last Episode]',colorA); 
	#	_addon.add_directory(pars,{'title':title},fanart=addst("LastEpisodeListedFANART"),img=addst("LastEpisodeListedIMG"),is_folder=True); 
	###
	_addon.add_directory({'mode':'About','site':site,'section':section},{'title':RoAFColoring('Despre','About')},is_folder=True,fanart=fanartSite,img=psgn('about')) #'http://i.imgur.com/0h78x5V.png') # iconSite
	###
	set_view('list',view_mode=addst('default-view')); eod()
### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	deb('mode',mode); 
	if (mode=='SectionMenu'): 		SectionMenu()
	elif (mode=='') or (mode=='main') or (mode=='MainMenu'): SectionMenu()
	elif (mode=='SubMenu'): 			SubMenu()
	elif (mode=='ListShows'): 		ListShows(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''),addpr('stitle',''),addpr('etitle',''),addpr('e',''),addpr('s',''),addpr('e2',''),addpr('wwT',''))
	elif (mode=='GetMedia'): 			GetMedia(url,addpr('title',''),addpr('imdb_id',''),addpr('img',''),addpr('fimg',''),addpr('stitle',''),addpr('etitle',''),addpr('e',''),addpr('s',''),addpr('e2',''),addpr('wwT',''))
	elif (mode=='Search'):				DoSearch(addpr('title',''),url)
	#elif (mode=='Hosts'): 				Browse_Hosts(url)
	#elif (mode=='Search'): 			Search_Site(title=addpr('title',''),url=url,page=page,metamethod=addpr('metamethod','')) #(site,section)
	#elif (mode=='SearchLast'): 	Search_Site(title=addst('LastSearchTitle'+SiteTag),url=url,page=page,metamethod=addpr('metamethod',''),endit=tfalse(addpr('endit','true'))) #(site,section)
	elif (mode=='About'): 				eod(); About()
	#elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='MenuAZ'): 				MenuAZ(url)
	elif (mode=='MenuGenre'): 		MenuGenre()
	elif (mode=='LatestShows'): 	LatestShows()
	elif (mode=='LatestMovies'): 	LatestMovies()
	elif (mode=='MenuYear'): 		MenuYear()
	elif (mode=='FavoritesList'): Fav_List(site=site,section=section,subfav=addpr('subfav',''))
	elif (mode=='PlayFromCHost'): 			PlayFromCHost(url)
	elif (mode=='PlayURL'): 						PlayURL(url)
	elif (mode=='PlayURLs'): 						PlayURLs(url)
	elif (mode=='PlayURLstrm'): 				PlayURLstrm(url)
	elif (mode=='PlayFromHost'): 				PlayFromHost(url)
	elif (mode=='PlayFromHostMT'): 			PlayFromHostMT(url)
	elif (mode=='PlayVideo'): 					PlayVideo(url)
	elif (mode=='PlayItCustom'): 				PlayItCustom(url,addpr('streamurl',''),addpr('img',''),addpr('title',''))
	elif (mode=='PlayItCustomL2A'): 		PlayItCustomL2A(url,addpr('streamurl',''),addpr('img',''),addpr('title',''))
	elif (mode=='Settings'): 						_addon.addon.openSettings() # Another method: _plugin.openSettings() ## Settings for this addon.
	elif (mode=='ResolverSettings'): 		import urlresolver; urlresolver.display_settings()  ## Settings for UrlResolver script.module.
	elif (mode=='ResolverUpdateHostFiles'):	import urlresolver; urlresolver.display_settings()  ## Settings for UrlResolver script.module.
	elif (mode=='TextBoxFile'): 				TextBox2().load_file(url,addpr('title','')); #eod()
	elif (mode=='TextBoxUrl'):  				TextBox2().load_url(url,addpr('title','')); #eod()
	elif (mode=='Download'): 						
		try: _addon.resolve_url(url)
		except: pass
		debob([url,addpr('destfile',''),addpr('destpath',''),str(tfalse(addpr('useResolver','true')))])
		DownloadThis(url,addpr('destfile',''),addpr('destpath',''),tfalse(addpr('useResolver','true')))
	elif (mode=='toJDownloader'): 			SendTo_JDownloader(url,tfalse(addpr('useResolver','true')))
	elif (mode=='cFavoritesEmpty'):  	fav__COMMON__empty( site=site,section=section,subfav=addpr('subfav','') ); xbmc.executebuiltin("XBMC.Container.Refresh"); 
	elif (mode=='cFavoritesRemove'):  fav__COMMON__remove( site=site,section=section,subfav=addpr('subfav',''),name=addpr('title',''),year=addpr('year','') )
	elif (mode=='cFavoritesAdd'):  		fav__COMMON__add( site=site,section=section,subfav=addpr('subfav',''),name=addpr('title',''),year=addpr('year',''),img=addpr('img',''),fanart=addpr('fanart',''),plot=addpr('plot',''),commonID=addpr('commonID',''),commonID2=addpr('commonID2',''),ToDoParams=addpr('todoparams',''),Country=addpr('country',''),Genres=addpr('genres',''),Url=url ) #,=addpr('',''),=addpr('','')
	elif (mode=='AddVisit'):							
		try: visited_add(addpr('title')); RefreshList(); 
		except: pass
	elif (mode=='RemoveVisit'):							
		try: visited_remove(addpr('title')); RefreshList(); 
		except: pass
	elif (mode=='EmptyVisit'):						
		try: visited_empty(); RefreshList(); 
		except: pass
	elif (mode=='refresh_meta'):			refresh_meta(addpr('video_type',''),TagAnimeName(addpr('title','')),addpr('imdb_id',''),addpr('alt_id',''),addpr('year',''))
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
