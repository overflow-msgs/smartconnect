import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import extract,downloader
import common; from common import *


if common.tfalse(common.SettingG("auto-update-package"))==True:
    try: common.deb("PowerPack Auto-Checker",str(common.SettingG("auto-update-package")))
    except: pass
    LatestRevision=common.getLastRev()
    try:
      if common.SettingG("first-time")=="false": FirstTimer=False
      else: FirstTimer=True
    except: FirstTimer=True
    try: common.debob(['Local Rev',common.SettingG("latest-revision"),'Online Rev',str(LatestRevision)])
    except: pass
    if (not LatestRevision==None) and (len(str(LatestRevision)) > 0) and (FirstTimer==False):
        if not common.SettingG("latest-revision")==LatestRevision:
            common.debob('attempting to execute powerpack updater.')
            #common.SettingS("latest-revision",LatestRevision); 
            #xbmc.executebuiltin('RunAddon(%s)' % common.addonId); 
            #xbmc.executebuiltin('RunScript(%s,"1","?name=SentFromService&mode=service")' % common.addonId); # doesn't work
            try: xbmc.executebuiltin('RunAddon(%s,"1","?name=SentFromService&mode=service")' % common.addonId); 
            except: xbmc.executebuiltin('RunAddon(%s)' % common.addonId); common.debob('trying 2nd method for addon execution.')
