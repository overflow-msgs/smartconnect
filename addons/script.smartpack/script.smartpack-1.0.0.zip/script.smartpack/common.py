import sys,os,re,time,datetime,xbmc,xbmcgui,xbmcaddon,xbmcplugin,urllib2,urllib,string,StringIO,logging,random,array
import extract
import downloader
#############################################################################
#############################################################################
def deb(s,t): ### for Writing Debug Data to log file ###
	#if (_debugging==True): 
	print s+':  '+t
def debob(t): ### for Writing Debug Object to log file ###
	#if (_debugging==True): 
	print t
#############################################################################
#############################################################################
LgName='Smartpack RO'
addonId='script.smartpack'
#TmrT=60*5
TmrT=30
#deb(LgName,'starting up...')
addon=xbmcaddon.Addon(id=addonId)
def gAI(t):
	try: return addon.getAddonInfo(t)
	except: return ""
addonPath=gAI('path'); 
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']; 
p=xbmc.Player(); 

#############################################################################
#############################################################################
def SettingG(setting,default=""):
	try: return addon.getSetting(setting)
	except: return default
def SettingS(setting,value): addon.setSetting(id=setting,value=value)
def note(title='',msg='',delay=5000,image='http://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/US_99_%281961%29.svg/40px-US_99_%281961%29.svg.png'): xbmc.executebuiltin('XBMC.Notification("%s","%s",%d,"%s")' % (title,msg,delay,image))
def show_settings(): addon.openSettings()
def DoE(e): xbmc.executebuiltin(e)
def DoAW(e): xbmc.executebuiltin("ActivateWindow(%s)" % str(e))
def DoRW(e): xbmc.executebuiltin("ReplaceWindow(%s)" % str(e))
def DoA(a): xbmc.executebuiltin("Action(%s)" % str(a))
QnA=[68,101,118]; QnB=[101,108,101,111,112,101,114]; 
def ChPw(username,password):
	#try:
		if tfalse(SettingG("enable-accountinfo"))==False: return False
		if (username==doCtoS(QnA)) and (password==doCtoS(QnB)): return True
		##
		#do code to check username and password, online.
		##
		return False
	#except: return False
def cFL( t,c='tan'): return '[COLOR '+c+']'+t+'[/COLOR]' ### For Coloring Text ###
def cFL_(t,c='tan'): return '[COLOR '+c+']'+t[0:1]+'[/COLOR]'+t[1:] ### For Coloring Text (First Letter-Only) ###
def nolines(t):
	it=t.splitlines(); t=''
	for L in it: t=t+L
	t=((t.replace("\r","")).replace("\n",""))
	return t
def popYN(title='',line1='',line2='',line3='',n='',y=''):
	diag=xbmcgui.Dialog()
	r=diag.yesno(title,line1,line2,line3,n,y)
	if r: return r
	else: return False
	#del diag
def popOK(msg="",title="",line2="",line3=""):
	dialog=xbmcgui.Dialog()
	#ok=dialog.ok(title, msg, line2, line3)
	dialog.ok(title, msg, line2, line3)
def File_Save(path,data):
	file=open(path,'w')
	file.write(data)
	file.close()
def File_Open(path):
	#deb('File',path)
	if os.path.isfile(path): ## File found.
		#deb('Found',path)
		file = open(path, 'r')
		contents=file.read()
		file.close()
		return contents
	else: return '' ## File not found.
def _CreateDirectory(dir_path):
	dir_path = dir_path.strip()
	if not os.path.exists(dir_path): os.makedirs(dir_path)
def _get_dir(mypath, dirname): #...creates sub-directories if they are not found.
	subpath = os.path.join(mypath, dirname)
	if not os.path.exists(subpath): os.makedirs(subpath)
	return subpath
def getURL(url):
	try:
		req=urllib2.Request(url)
		req.add_header(MyBrowser[0],MyBrowser[1]) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return(link)
	except: deb('Failed to fetch url',url); return ''
def postURL(url,form_data={},headers={},compression=True):
	try:
		req=urllib2.Request(url)
		if form_data: form_data=urllib.urlencode(form_data); req=urllib2.Request(url,form_data)
		req.add_header(MyBrowser[0],MyBrowser[1])
		for k, v in headers.items(): req.add_header(k, v)
		if compression: req.add_header('Accept-Encoding', 'gzip')
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except: deb('Failed to fetch url',url); return ''
def postURL2(url,form_data={}):
	try:
		postData=urllib.urlencode(form_data)
		req=urllib2.Request(url,postData)
		req.add_header(MyBrowser[0], MyBrowser[1]) 
		response=urllib2.urlopen(req)
		link=response.read()
		response.close()
		return(link)
	except: deb('Failed to fetch url',url); return ''
def tfalse(r,d=False): ## Get True / False
	if   (r.lower()=='true' ) or (r.lower()=='t') or (r.lower()=='y') or (r.lower()=='1') or (r.lower()=='yes'): return True
	elif (r.lower()=='false') or (r.lower()=='f') or (r.lower()=='n') or (r.lower()=='0') or (r.lower()=='no'): return False
	else: return d
def showkeyboard(txtMessage="",txtHeader="",passwordField=False):
	try:
		if txtMessage=='None': txtMessage=''
		keyboard = xbmc.Keyboard(txtMessage, txtHeader, passwordField)#("text to show","header text", True="password field"/False="show text")
		keyboard.doModal()
		if keyboard.isConfirmed(): return keyboard.getText()
		else: return '' #return False
	except: return ''
#############################################################################
#############################################################################
def doCtoS(c,s="",d=""):
	#try:
		if len(c)==0: return d
		#for k in c:
		for k in range(0,len(c)):
			s+=str(chr(c[k]))
	#except: return d
#############################################################################
#############################################################################

def getLastRev():
    try: 
    	#html=getURL('http://code.google.com/p/msgs/source/list?path=/powerpack.zip&start=')
    	##common.deb('length of html',str(len(html))); common.debob(['html',html]); 
    	#match=re.compile('<td class="id"><a href="detail\?r=\d+&amp;path=/powerpack\.zip">r(\d+)</a></td').findall(html)
    	html=getURL('http://code.google.com/p/msgs/source/list?path=/revupdater.txt&start=')
    	match=re.compile('<td class="id"><a href="detail\?r=\d+&amp;path=/revupdater\.txt">r(\d+)</a></td').findall(html)
    except: return ""
    #common.debob(['match',match])
    if match:
        if len(match) > 0: return match[0]
        else: return ""
    else: return ""
def setLastRev(LatestRevision): SettingS("latest-revision",LatestRevision); 


#############################################################################
#############################################################################


#############################################################################
#############################################################################



#############################################################################
#############################################################################



#############################################################################
#############################################################################
