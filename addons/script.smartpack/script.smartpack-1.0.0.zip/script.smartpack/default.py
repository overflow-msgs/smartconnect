## ### ## Imports
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import extract,downloader
import common as Common; from common import *
ADDON = xbmcaddon.Addon(id='script.smartpack')
## ### ## Settings
zipfile     ='http://89.40.234.61/smartpack.zip'
zipHost     ='http://89.40.234.61/'
HOME        ='http://89.40.234.61/home.txt'
#FAVSREAD    ='http://msgs.googlecode.com/svn/favourites.xml'
USERDATA    =xbmc.translatePath(os.path.join('special://home','userdata',''))
ADDONDATA   =xbmc.translatePath(os.path.join('special://home','userdata','addon_data'))
ADDONS   =xbmc.translatePath(os.path.join('special://home','userdata','addons'))
#FAVS        =xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
xbmcfolder  =xbmc.translatePath(os.path.join('special://home',''))
packages    =xbmc.translatePath(os.path.join('special://home','addons','packages'))
rootFolder  ='./root/' ## might need to remove the last / ##
#rootFolder  =xbmc.translatePath('/root/')
#rootFolder  =xbmc.translatePath(os.path.join('special://home','..')); deb('rootFolder',rootFolder); 
home        =os.path.join(packages,'home.txt')
## ### ## 
print "==="; print sys.argv; print "==="
def ServiceFolder():
    addDir(name="Actualizare Smart Pack",mode="main2",isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
## ### ## 
def CATEGORIES(mode=''):
        LatestRevision=str(Common.getLastRev())
        Common.deb('LatestRevision',str(LatestRevision)); 
        dialog = xbmcgui.Dialog()
        if dialog.yesno("Power Pack"+" (r%s)" % str(LatestRevision), "Smart Connect nu isi asuma", "responsabilitatea pentru functionarea"," continua a continutului din internet","Nu","Da"):
            dp=xbmcgui.DialogProgress(); dp.create('Smart Pack','Descarcare ','Fisiere....','Va rugam asteptati')
            FirstTime=Common.SettingG("first-time")
            if (len(Common.SettingG("setup-sources"))==0) or (Common.SettingG("setup-sources").lower()=='true'): 
                dp.update(0,'',"Actualizare surse...");
                Common.debob("doing sources...")
                SourcesInstaller()
                Common.SettingS("setup-sources","false")
            profile=xbmc.getInfoLabel("System.ProfileName")
            #dp=xbmcgui.DialogProgress(); dp.create('Power Pack','Working... ','[ Installing ]','Please Wait')
            ## ### ## Download Addon Package.
            lib=os.path.join(packages,'smartpack.zip')#url of package to download
            lib3=os.path.join(packages,'menu.zip')#url of package to download
            zipfile3=zipHost+"menu.zip"
            #check3=os.path.join(ADDONDATA,'plugin.video.p2p-streams','Lists','TV Romania.txt')
            #zipfile2=zipHost+".ACEStream.zip"
            #lib2=os.path.join(packages,'ACEStream.zip')#url of package to download
            #check2=xbmc.translatePath(os.path.join(rootFolder,'.ACEStream')); deb('check2',check2); 
            #ADDONDATA
            if (len(Common.SettingG("do-download"))==0) or (Common.tfalse(Common.SettingG("do-download"))==True): 
                dp.update(0,'Descarcare',"smartpack.zip");
                Common.debob('se descarca "%s" to "%s"' % (zipfile,lib))
                downloader.download(zipfile,lib,dp)#download package
            #####\/## removed ##\/##
            ###if (len(Common.SettingG("do-acestream"))==0) or (Common.tfalse(Common.SettingG("do-acestream"))==True): 
            ###        if os.path.exists(check2)==False: dp.update(0,'Downloading',"ACEStream"); Common.debob('downloading "%s" to "%s"' % (zipfile2,lib2)); downloader.download(zipfile2,lib2,dp)#download package
            if (len(Common.SettingG("do-p2pstreams"))==0) or (Common.tfalse(Common.SettingG("do-p2pstreams"))==True): 
                    #if os.path.isfile(check3)==False:
                        dp.update(0,'Descarcare',"menu.zip");
                        Common.debob('se descarca "%s" to "%s"' % (zipfile3,lib3))
                        downloader.download(zipfile3,lib3,dp)#download package
            ## ### ## 
            if (len(Common.SettingG("do-extract"))==0) or (Common.tfalse(Common.SettingG("do-extract"))==True): 
                ## ### ## 
                dp.update(0,'Se extrage',"smartpack.zip"); #xbmc.sleep(1000);
                Common.debob('extras din "%s" to "%s"' % (lib,xbmcfolder))
                extract.all(lib,xbmcfolder,dp)#extract package
            ## ### ## 
            #####\/## removed ##\/##
            ###if (len(Common.SettingG("do-acestream"))==0) or (Common.tfalse(Common.SettingG("do-acestream"))==True): 
            ###        if os.path.exists(check2)==False:
            ###            try:
            ###        	      dp.update(0,'Extracting',"ACEStream"); #xbmc.sleep(1000); 
            ###        	      Common.debob('extracting from "%s" to "%s"' % (lib2,rootFolder))
            ###        	      extract.all(lib2,rootFolder,dp)#extract package
            ###            except Exception,e: debob(str(e)); pass
            ###            except: pass
            ## ### ## 
            if (len(Common.SettingG("do-p2pstreams"))==0) or (Common.tfalse(Common.SettingG("do-p2pstreams"))==True): 
                    #if os.path.isfile(check3)==False:
                        dp.update(0,'Se extrage',"menu.zip"); #xbmc.sleep(1000);
                        Common.debob('extras din "%s" to "%s"' % (lib3,ADDONDATA))
                        extract.all(lib3,ADDONDATA,dp)#extract package
            ## ### ## Setup favorites list.
            #####\/## removed ##\/##
            #if (len(Common.SettingG("setup-favs"))==0) or (Common.SettingG("setup-favs").lower()=='true'): 
            #    dp.update(0,'Updating',"Favorites..."); 
            #    xbmc.sleep(1000); 
            #    Common.debob("doing favs...")
            #    _a_=OPEN_URL(FAVSREAD); f=open(FAVS,mode='w'); f.write(_a_); f.close()
            #    Common.SettingS("setup-favs","false")
            ## ### ## Refresh XBMC's current list of installed addons.
            xbmc.executebuiltin('UpdateLocalAddons'); 
            ## ### ## Run AutoUpdate.
            if Common.tfalse(Common.SettingG("auto-update-addons"))==True: xbmc.executebuiltin("UpdateAddonRepos")
            ## ### ## Setup Home Screen Links.
            setupHomeMenu=Common.SettingG("setup-home").lower()
            if setupHomeMenu=='ask': r=dialog.yesno("Power Pack"+" (r%s)" % str(LatestRevision), "Would you like to update the Home menu?", "","","No","Yes")
            else: r=False
            if (r==True) or (len(setupHomeMenu)==0) or (setupHomeMenu=='always'): 
            #if (len(Common.SettingG("setup-home"))==0) or (Common.SettingG("setup-home").lower()=='true'): 
                dp.update(0,'Updating',"Home Screen Shortcuts..."); 
                xbmc.sleep(5000); 
                Common.debob("doing home shortcuts...")
                a=OPEN_URL(HOME).replace('&quot;','') .replace('&amp;','&')
                match=re.compile('<setting type="(.+?)" name="skin.aeon.nox.5.(.+?)">(.+?)</setting>').findall(a)
                for type,string,setting in match:
                    xbmc.executebuiltin("Skin.Set%s(%s,%s)"%(type.title(),string,setting))
                #Common.SettingS("setup-home","false")
                ## ### ## home.txt
            if xbmc.getCondVisibility('Skin.HasSetting(packfirstrun)'):
                Common.debob("doing packfirstrun...")
                xbmc.executebuiltin( "Addon.OpenSettings(script.dotsmart.runtime)" )
                xbmc.executebuiltin( "Skin.ToggleSetting(packfirstrun)" )
            #else: xbmc.executebuiltin('ReloadSkin()'); xbmc.executebuiltin("LoadProfile(%s)" % profile)
            Common.SettingS("first-time","false")
            Common.debob("doing setLastRev...")
            Common.setLastRev(LatestRevision)
            xbmc.sleep(1000); 
            #dp.update(98,'Preparing to ',"Adjust settings for sopcast...")
            #try: SopCastFixer()
            #except: pass
            dp.update(98,'Se pregateste ',"Reincarcare...")
            xbmc.sleep(5000); 
            Common.debob("se reincarca...")
            xbmc.executebuiltin('UnloadSkin()'); 
            xbmc.executebuiltin('ReloadSkin()'); 
            dp.update(100,' ',"Gata")
            Common.popOK("* DONE *",title=Common.LgName+" (r%s)" % str(LatestRevision),line2="r"+str(LatestRevision)+" instalata.",line3='Apasati tasta "OK" pe telecomanda.')
            xbmc.sleep(1000); 
            DoA('Back'); #Don't put a "#" before this line or xbmc might crash.
            #DoRW(0)
            #DoAW('home')
            ## ### ## 
## ### ## 
def SopCastFixer():
	return
	## ### ## 
## ### ## 
def SourcesInstaller():
    zz=[]; path=os.path.join(xbmc.translatePath('special://home'),'userdata','sources.xml')
    if not os.path.exists(path):
        str='<sources><files></files></sources>'
    else: f=open(path,mode='r'); str=f.read(); f.close()
    zz.append(['http://fusion.xbmchub.com','Fusion'])
    zz.append(['http://srp.nu/gotham','Super Repo - Gotham'])
    zz.append(['http://srp.nu/kodi','Super Repo - Kodi'])
    zz.append(['http://xfinity.xunitytalk.com','.[COLOR blue]X[/COLOR]finity Installer'])
    for zUrl,zName in zz:
        if not zUrl in str:
            if '</files>' in str: str=str.replace('</files>','<source><name>%s</name><path pathversion="1">%s</path></source></files>' % (zName,zUrl))
            else: str=str.replace('</sources>','<files><source><name>%s</name><path pathversion="1">%s</path></source></files></sources>' % (zName,zUrl))
    SAVE_To_FILE(path,str)
## ### ## 
def SAVE_To_FILE(path,data): f=open(path,mode='w'); f.write(data); f.close()
## ### ## 
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
## ### ## 
def get_params():
    param=[]; paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]; cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&'); param={}
        for i in range(len(pairsofparams)):
            splitparams={}; splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
    return param
## ### ## 
def addDir(name="",mode="",url="",iconimage="",fanart="",description="",common="",isFolder=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(str(mode))+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&common="+urllib.quote_plus(common)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
    liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
    return ok
## ### ## below tells plugin about the views                
def setView(content, viewType):
    # set content type so library shows more views and info
    if content: xbmcplugin.setContent(int(sys.argv[1]),content)
    if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType))#<<<-----then get the view type
## ### ## Param Setup
params=get_params(); url=None; name=None; mode=None; iconimage=None; fanart=None; description=None; common=None; 
try:    url=urllib.unquote_plus(params["url"])
except: url=""
try:    name=urllib.unquote_plus(params["name"])
except: name=""
try:    iconimage=urllib.unquote_plus(params["iconimage"])
except: iconimage=""
try:    mode=urllib.unquote_plus(params["mode"])
except: mode=""
try:    fanart=urllib.unquote_plus(params["fanart"])
except: fanart=""
try:    description=urllib.unquote_plus(params["description"])
except: description=""
try:    common=urllib.unquote_plus(params["common"])
except: common=""
print {"Mode":str(mode),"URL":str(url)}; print {"Name":str(name),"IconImage":str(iconimage)}
## ### ## Mode Switch
if mode==None or len(str(mode))==0 or mode=="main": CATEGORIES()
elif mode=="main2": CATEGORIES(str(mode))
elif mode=="service": ServiceFolder()
## ### ## 
xbmcplugin.endOfDirectory(int(sys.argv[1]))
