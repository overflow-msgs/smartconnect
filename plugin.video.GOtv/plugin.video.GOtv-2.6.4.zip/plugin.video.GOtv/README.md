======================
GOtv XBMC Addon
======================

About
-----
Watch tv shows from various sources


Attributions
---------------------
- Main icon and fanart by jokster | http://www.xbmchub.com
- Dutch translation by falos | http://www.xbmchub.com
- French translation by nek | http://www.xbmchub.com
- Polish translation by kodishu | http://www.xbmchub.com
- Portuguese translation by enen92 | http://www.xbmchub.com
- Romanian translation by timmygotcha | http://www.xbmchub.com
- Main icon set is based on work done by DryIcons | http://dryicons.com
- Additional icons are based on work done by David Lanham | http://www.dlanham.com


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html